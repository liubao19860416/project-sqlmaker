
-- ----------------------------
-- Table structure for t_errorcode
-- ----------------------------
DROP TABLE IF EXISTS `t_errorcode`;
CREATE TABLE `t_errorcode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `errorCode` varchar(32) NOT NULL COMMENT '异常码编码',
  `message` varchar(128) DEFAULT NULL COMMENT '异常码描述信息',
  PRIMARY KEY (`id`),
  KEY `CINO` (`errorCode`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;
